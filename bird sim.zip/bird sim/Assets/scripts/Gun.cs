﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{

    public GameObject bullet;
    public float speed = 100f;
   private GameObject _instBullet;
  bool automatic;
    CountSystem core;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Counting.score += 1;


        

        if (Input.GetMouseButtonDown(0))
          {
              automatic = true;
          }
          if (Input.GetMouseButton(0) && automatic && Counting.score>0 )
          {
              _instBullet = Instantiate(bullet, transform.position, Quaternion.identity) as GameObject;
              Rigidbody instBulletRigidbody = _instBullet.GetComponent<Rigidbody>();
              instBulletRigidbody.AddForce(transform.TransformDirection(Vector3.forward) * speed);
              Destroy(_instBullet, 5);
            Counting.score -= 10;
          }

          if (Input.GetMouseButtonUp(0))
          {
              automatic = false;
          }
      
       



    }

  
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThirdPChar : MonoBehaviour
{
    public float speed;
    public float fly;
    float jump;
       public float high=1;
    public GameObject grounded;
    bool skeet=false;
    // Update is called once per frame
    void Update()
    {
        PlayerMovement();
    }

    void PlayerMovement()
    {
        float hor = Input.GetAxis("Horizontal");
        float ver = Input.GetAxis("Vertical");
        jump = Input.GetAxis("Jump");
  if (skeet)
        {
            transform.position += transform.forward * Time.deltaTime * fly;
            skeet = false;
        }
        if (!skeet && Input.GetKey(KeyCode.Space))
        {
         
            skeet = true;
        }
      
       
        


        Vector3 PlayerMovement = new Vector3(hor, jump*high, ver) * speed * Time.deltaTime;
        transform.Translate(PlayerMovement, Space.Self);




    }
}
